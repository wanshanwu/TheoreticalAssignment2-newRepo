
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class ATMGUI extends JFrame {
	
	JPanel panel1 = new JPanel();
	JPanel panel2 = new JPanel();
	JPanel panel3 = new JPanel();
	JPanel panel4 = new JPanel();
	JTextArea ta1;
	int i = 0;int account = 0;
	JButton [] Buttonarray = new JButton[12];
	class ButtonListener3 implements ActionListener{
		 public void actionPerformed(ActionEvent e){
			 String s = ((JButton)e.getSource()).getText();
				switch(s){
				case("1"):
					account= account + 100;
					ta1.setText("���ѳɹ�����100Ԫ");
					break;
				case("2"):
					account = account + 300;
				ta1.setText("���ѳɹ�����300Ԫ");
				break;
				case("3"):
					account = account + 500;
				ta1.setText("���ѳɹ�����500Ԫ");
				break;
				case("4"):
					account = account + 1000;
				ta1.setText("���ѳɹ�����1000Ԫ");
				break;
				case("5"):
					account = account + 2000;
				ta1.setText("���ѳɹ�����2000Ԫ");
				break;
				case("6"):
					account = account + 5000;
				ta1.setText("���ѳɹ�����5000Ԫ");
				break;
				case("7"):
					Exit();
				}
	 }
	}
	 ButtonListener3 blc = new ButtonListener3();
	 class ButtonListener4 implements ActionListener{
		 public void actionPerformed(ActionEvent e){
			 String s = ((JButton)e.getSource()).getText();
				switch(s){
				case("1"):
					account= account - 100;
				ta1.setText("���ѳɹ�ȡ��100Ԫ");
				break;
				case("2"):
					account = account - 300;
				ta1.setText("���ѳɹ�ȡ��300Ԫ");
				break;
				case("3"):
					account = account - 500;
				ta1.setText("���ѳɹ�ȡ��500Ԫ");
				break;
				case("4"):
					account = account - 1000;
				ta1.setText("���ѳɹ�ȡ��1000Ԫ");
				break;
				case("5"):
					account = account - 2000;
				ta1.setText("���ѳɹ�ȡ��2000Ԫ");
				break;
				case("6"):
					account = account - 5000;
				ta1.setText("���ѳɹ�ȡ��5000Ԫ");
				break;
				case("7"):
					Exit();
				}
	 }
	}
	 ButtonListener4 bld = new ButtonListener4();
	class ButtonListener2 implements ActionListener{
		public void actionPerformed(ActionEvent e){
			String s = ((JButton)e.getSource()).getText();
			switch(s){
			case("1"):
				View();
				break;
			case("2"):
				Withdraw();
			break;
			case("3"):
				Deposit();
			break;
			case("4"):
				Exit();
			break;
			}
		}
	}
	 ButtonListener2 blb = new ButtonListener2();
	 class ButtonListener1 implements ActionListener{
		 public void actionPerformed(ActionEvent e){
			 String s = ((JButton)e.getSource()).getText();
			 if(s == "ȷ��"){Account();}
			 else{
			 if(i<19){
			ta1.insert((s),42+i);
			i = i + 1;
		}
			 else{ta1.insert((s),66+i);i=i+1;}
			 }
	 }
	}
	 ButtonListener1 bla = new ButtonListener1();
		ATMGUI(){
			setTitle("��������ATM");
			ta1 = new JTextArea("Welcome\r\nPlease enter your account number:\r\nPlease enter your pin:",5,40);
			panel2.setLayout(new GridLayout(3,4));
			panel3.setLayout(new GridLayout(4,1));
			ta1.setBorder(null);
		panel1.add(ta1);
		 for(int i = 0;i<10;i++){
			 Buttonarray[i] = new JButton(""+i);
			 panel2.add(Buttonarray[i]);
		 }
		 for(int i = 0;i<10;i++){
				 Buttonarray[i].addActionListener(bla);
			 }
		 JButton b =new JButton("ȷ��");
		 JButton b1 =new JButton("��ɾ");
		 b.addActionListener(bla);
		 panel2.add(b);panel2.add(b1);
		 setLayout(null);
		 setBounds(0,0,500,500);
		 add(panel2);add(panel4);
		 add(panel1);add(panel3);
		 panel1.setBounds(10,10,450,200);
		 panel2.setBounds(10,220,200,200);
		 panel3.setBounds(250,210,200,100);
		 	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setVisible(true);
		}
		
		void Account(){
		ta1.setText("MainView\r\n1-view my balance\r\n2-withdraw money\r\n3-deposit funds\r\n4-Exit\r\nEnter your choice");
		 for(int i = 0;i<10;i++){
			 Buttonarray[i].removeActionListener(bla);
		 }
		 for(int i = 0;i<10;i++){
			 Buttonarray[i].addActionListener(blb);
		 }
		
		}
		void View(){
			ta1.setText("your balance is:"+account+"\r\n7-����");
		}
		void Withdraw(){
			ta1.setText("Withdraw manu\r\n1-100     2-300\r\n3-500     4-1000\r\n5-2000     6-5000\r\n7-����\r\nchoose a withdraw amount");
			 for(int i = 0;i<10;i++){
				 Buttonarray[i].removeActionListener(blb);
			 }
			 for(int i = 0;i<10;i++){
				 Buttonarray[i].addActionListener(blc);
			 }
		}
		
		void Deposit(){
			ta1.setText("deposit manu\r\n1-100     2-300\r\n3-500     4-1000\r\n5-2000     6-5000\r\n7-����\r\nchoose a deposit amount");
			 for(int i = 0;i<10;i++){
				 Buttonarray[i].removeActionListener(blb);
			 }
			 for(int i = 0;i<10;i++){
				 Buttonarray[i].addActionListener(bld);
			 }
		}
		void Exit(){
			ta1.setText("Welcome\r\nPlease enter your account number:\r\nPlease enter your pin:");
			 for(int i = 0;i<10;i++){
				 Buttonarray[i].removeActionListener(blb);
				 Buttonarray[i].removeActionListener(blc);
				 Buttonarray[i].removeActionListener(bld);
			 }
			 for(int i = 0;i<10;i++){
				 Buttonarray[i].addActionListener(bla);
			 }
		}
		public static void main(String[] args){
			try{
			ATMGUI atm = new ATMGUI();
			
			}
			catch(IllegalArgumentException e){}
		}
}
